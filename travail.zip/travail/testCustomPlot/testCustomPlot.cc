#include <iostream>
#include <vector>
#include <QApplication>
#include "Toupie.h"
#include "Dessinable.h"

int main(){
























    return 0;
}
